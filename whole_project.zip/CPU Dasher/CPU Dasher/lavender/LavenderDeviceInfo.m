//
//  LavenderDeviceInfo.m
//  Lavender
//
//  Created by Zenny Chen on 11-12-21.
//  Copyright (c) 2011年 chenyi. All rights reserved.
//

#import "LavenderDeviceInfo.h"
#import <objc/message.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/sysctl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/sockio.h>
#include <net/if.h>
#include <net/ethernet.h>
#include <errno.h>
#include <net/if_dl.h>
#include <ifaddrs.h>
#include <mach/machine.h>


#define BUFFERSIZE	1024

#define LAVENDER_UUID_DOMAIN        @"LavenderDevice_UUID_Domain"

#pragma mark - sysctl relevant functions

static BOOL GetMACAddress(char macAddr[64])
{
    int                 mib[6];
    size_t              len;
    char                buf[BUFFERSIZE];
    unsigned char       *ptr;
    struct if_msghdr    *ifm;
    struct sockaddr_dl  *sdl;
    
    mib[0] = CTL_NET;
    mib[1] = AF_ROUTE;
    mib[2] = 0;
    mib[3] = AF_LINK;
    mib[4] = NET_RT_IFLIST;
    
    if ((mib[5] = if_nametoindex("en0")) == 0) {
        printf("Error: if_nametoindex error/n");
        return FALSE;
    }
    
    if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 1/n");
        return FALSE;
    }

    if (sysctl(mib, 6, buf, &len, NULL, 0) < 0) {
        printf("Error: sysctl, take 2");
        return FALSE;
    }
    
    ifm = (struct if_msghdr *)buf;
    sdl = (struct sockaddr_dl *)(ifm + 1);
    ptr = (unsigned char *)LLADDR(sdl);

    sprintf(macAddr, "%.2X:%.2X:%.2X:%.2X:%.2X:%.2X", *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5));

    return TRUE;
}

static BOOL GetWiFiIPAddress(char wifiAddr[64])
{
    BOOL success;
    struct ifaddrs *addrs;
    const struct ifaddrs *cursor;
    
    memset(wifiAddr, 0, 64);

    success = getifaddrs(&addrs) == 0;
    if (success) 
    {
        success = NO;
        cursor = addrs;
        while(cursor != NULL) 
        {
            // the second test keeps from picking up the loopback address
            if (cursor->ifa_addr->sa_family == AF_INET && (cursor->ifa_flags & IFF_LOOPBACK) == 0)
            {
                // Wi-Fi adapter
                if (strcmp(cursor->ifa_name, "en0") == 0)
                {
                    strcpy(wifiAddr, inet_ntoa(((struct sockaddr_in *)cursor->ifa_addr)->sin_addr));
                    success = YES;
                    break;
                }
            }
            cursor = cursor->ifa_next;
        }
        
        freeifaddrs(addrs);
        return success;
    }
    
    return NO;
}

static int GetMachine(char buf[64])
{
    size_t size = 64;
    
    return sysctlbyname("hw.machine", buf, &size, NULL, 0);;
}

static const char* GetCPUType(void)
{
    NSInteger ret = 0;
    size_t size = sizeof(ret);
    
    int error = sysctlbyname("hw.cputype", &ret, &size, NULL, 0);
    
    if(error != 0)
        return "Unknown type";
    
    switch(ret)
    {            
        case CPU_TYPE_ARM:
            return "ARM";
            
        case CPU_TYPE_ARM64:
            return "ARM64";
            
        case CPU_TYPE_HPPA:
            return "HPPA";
            
        case CPU_TYPE_I860:
            return "I860";
            
        case CPU_TYPE_MC680x0:
            return "MC680x0";
            
        case CPU_TYPE_MC88000:
            return "MC88000";
            
        case CPU_TYPE_MC98000:
            return "MC98000";
            
        case CPU_TYPE_POWERPC:
            return "POWERPC";
            
        case CPU_TYPE_POWERPC64:
            return "POWERPC64";
            
        case CPU_TYPE_SPARC:
            return "SPARC";
            
        case CPU_TYPE_VAX:
            return "VAX";
            
        case CPU_TYPE_X86:
            return "X86";
            
        case CPU_TYPE_X86_64:
            return "X86_64";
            
        case CPU_TYPE_ANY:
            
        default:
            return "Unknown type";
    }
}

static const char* GetARMArch(NSInteger *pValue)
{
    NSInteger ret = 0;
    size_t size = sizeof(ret);

    sysctlbyname("hw.cpusubtype", &ret, &size, NULL, 0);

    if(size == 0)
        return "Unknown Arch";
    
    switch(ret)
    {
        case CPU_SUBTYPE_ARM_ALL:
            *pValue = LAVENDER_DEVICE_ARM_ISA_SUPPORT_DEFAULT;
            return "ARM";
            
        case CPU_SUBTYPE_ARM64_V8:
            *pValue = LAVENDER_DEVICE_ARM_ISA_SUPPORT_NEON_VFPv4;
            return "ARMv8";
            
        case CPU_SUBTYPE_ARM_V4T:
            *pValue = LAVENDER_DEVICE_ARM_ISA_SUPPORT_DEFAULT;
            return "ARMv4T";
            
        case CPU_SUBTYPE_ARM_V5TEJ:
            *pValue = LAVENDER_DEVICE_ARM_ISA_SUPPORT_DEFAULT;
            return "ARMv5TEJ";
            
        case CPU_SUBTYPE_ARM_V6:
            *pValue = LAVENDER_DEVICE_ARM_ISA_SUPPORT_ARMv6;
            return "ARMv6";
            
        case CPU_SUBTYPE_ARM_V7:
            *pValue = LAVENDER_DEVICE_ARM_ISA_SUPPORT_NEON;
            return "ARMv7";
            
        case CPU_SUBTYPE_ARM_V7F:
            *pValue = LAVENDER_DEVICE_ARM_ISA_SUPPORT_NEON;
            return "ARMv7F";
            
        case CPU_SUBTYPE_ARM_V7S:
            *pValue = LAVENDER_DEVICE_ARM_ISA_SUPPORT_NEON_VFPv4;
            return "ARMv7S";
            
        case CPU_SUBTYPE_ARM_V7K:
            *pValue = LAVENDER_DEVICE_ARM_ISA_SUPPORT_NEON;
            return "ARMv7K";
            
        case CPU_SUBTYPE_ARM_V6M:
            *pValue = LAVENDER_DEVICE_ARM_ISA_SUPPORT_ARMv6;
            return "ARMv6M";
            
        case CPU_SUBTYPE_ARM_V7M:
            *pValue = LAVENDER_DEVICE_ARM_ISA_SUPPORT_NEON;
            return "ARMv7M";
            
        case CPU_SUBTYPE_ARM_V7EM:
            *pValue = LAVENDER_DEVICE_ARM_ISA_SUPPORT_NEON;
            return "ARMv7EM";
            
        case 4:
            return "X86";
            
        default:
            return "ARM";
    }
}

static LavenderDeviceInfo* s_lavenderDeviceInfo;

extern int freqTest(int cycles);
extern void jumpCost(int cycles);

static void GetCPUFrequency(void)
{
    volatile NSTimeInterval times[500];
    
    int sum = 0;
    
    for(int i = 0; i < 500; i++)
    {
        times[i] = [[NSProcessInfo processInfo] systemUptime];
        sum += freqTest(10000);
        times[i] = [[NSProcessInfo processInfo] systemUptime] - times[i];
    }
    
    NSTimeInterval time = times[0];
    for(int i = 1; i < 500; i++)
    {
        if(time > times[i])
            time = times[i];
    }

    double freq = 1300000.0 / time;
    s_lavenderDeviceInfo->absoluteFrequency = freq;
    s_lavenderDeviceInfo->cpuFreq = (int)freq;
}

static int GetByteOrder(void)
{
    size_t size = 4;
    int ret;
    
    int error = sysctlbyname("hw.byteorder", &ret, &size, NULL, 0);
    
    return error == 0? ret == 1234 : YES;
}

static int GetPageSize(void)
{
    size_t size = 4;
    int ret;
    
    int error = sysctlbyname("hw.pagesize", &ret, &size, NULL, 0);
    
    return error == 0? ret : 0;
}

static long long GetCacheLineSize(void)
{
    size_t size = 8;
    long long ret;
    
    int error = sysctlbyname("hw.cachelinesize", &ret, &size, NULL, 0);
    
    return error == 0? ret : 0;
}

static long long GetL1DCacheSize(void)
{
    size_t size = 8;
    long long ret;
    
    int error = sysctlbyname("hw.l1dcachesize", &ret, &size, NULL, 0);
    
    return error == 0? ret : 0;
}

static long long GetL1ICacheSize(void)
{
    size_t size = 8;
    long long ret;
    
    int error = sysctlbyname("hw.l1icachesize", &ret, &size, NULL, 0);
    
    return error == 0? ret : 0;
}

static long long GetL2CacheSize(void)
{
    size_t size = 8;
    long long ret;
    
    int error = sysctlbyname("hw.l2cachesize", &ret, &size, NULL, 0);
    
    return error == 0? ret : 0;
}

static long long GetL3CacheSize(void)
{
    size_t size = 8;
    long long ret;
    
    int error = sysctlbyname("hw.l3cachesize", &ret, &size, NULL, 0);
    
    return error == 0? ret : 0;
}

static long long GetMemSize(void)
{
    size_t size = 8;
    long long ret;
    
    int error = sysctlbyname("hw.memsize", &ret, &size, NULL, 0);
    
    return error == 0? ret : 0;
}

/*
static void GetMachineMode(char buf[64])
{
    size_t size = 4;
    int infos[2] = { CTL_HW, HW_MODEL };

    sysctl(infos, 2, buf, &size, NULL, 0);
}
*/

@implementation LavenderDeviceInfo

#pragma mark - get low-level info

- (void)getMACAddress
{
    char addr[64];
    
    macAddr = GetMACAddress(addr)? [[NSString alloc] initWithCString:addr encoding:NSASCIIStringEncoding] : [[NSString alloc] initWithString:@"00:00:00:00:00:00"];
}

- (void)getIPAddress
{
    char addr[64];
    
    ipAddr = GetWiFiIPAddress(addr)? [[NSString alloc] initWithCString:addr encoding:NSASCIIStringEncoding] : [[NSString alloc] initWithString:@"0.0.0.0"];
}

- (void)getMachine
{
    char buf[64];
    memset(buf, 0, sizeof(buf));
    
    GetMachine(buf);

    machineDetail = [[NSString alloc] initWithCString:buf encoding:NSASCIIStringEncoding];
}

- (void)getARMArch
{
    cpuType = [[NSString alloc] initWithCString:GetCPUType() encoding:NSASCIIStringEncoding];
    armArch = [[NSString alloc] initWithCString:GetARMArch(&isaSupport) encoding:NSASCIIStringEncoding];
    
    isLittleEndian = GetByteOrder();
    pageSize = GetPageSize();
}

- (void)getCPUFreq
{
    GetCPUFrequency();
}

- (void)getCacheInfo
{
    cachelineSize = GetCacheLineSize();
    l1dCache = GetL1DCacheSize();
    l1iCache = GetL1ICacheSize();
    l2Cache = GetL2CacheSize();
    l3Cache = GetL3CacheSize();
}

#pragma mark - get device info

- (void)getDeviceInfo
{
    UIDevice *device = [UIDevice currentDevice];
    
    // get device category
    deviceCategory = [[NSString alloc] initWithString:[device model]];
    
    // get OS verison
    osVersion = [[NSString alloc] initWithString:[device systemVersion]];
    
    // get number of cores
    nCores = [[NSProcessInfo processInfo] processorCount];
    
    // get memory size
    memSize = GetMemSize();
    
	return ;
}


#pragma mark - get screen info

- (void)getScreenInfo
{
    UIScreen *screen = [UIScreen mainScreen];
    
    CGRect bounds = [screen bounds];
    
    screenSize = [[NSString alloc] initWithFormat:@"%dx%d", (int)bounds.size.width, (int)bounds.size.height];
    
    if([screen respondsToSelector:@selector(scale)])
        pixelScale = (double)[screen scale];
    else
        pixelScale = 1.0;
}

#pragma mark - init and release

- (void)initMembers
{
    [self getMACAddress];
    [self getIPAddress];
    [self getMachine];
    [self getARMArch];
    [self getCPUFreq];
    [self getCacheInfo];
    [self getDeviceInfo];
    [self getScreenInfo];
}

- (void)dealloc
{
    // info from system
    if(macAddr != nil)
    {
        [macAddr release];
        macAddr = nil;
    }
    if(ipAddr != nil)
    {
        [ipAddr release];
        ipAddr = nil;
    }
    if(machineDetail != nil)
    {
        [machineDetail release];
        machineDetail = nil;
    }
    if(cpuType != nil)
    {
        [cpuType release];
        cpuType = nil;
    }
    if(armArch != nil)
    {
        [armArch release];
        armArch = nil;
    }
    
    // info from device info
    if(deviceCategory != nil)
    {
        [deviceCategory release];
        deviceCategory = nil;
    }
    if(osVersion != nil)
    {
        [osVersion release];
        osVersion = nil;
    }
    
    // info from screen info
    if(screenSize != nil)
    {
        [screenSize release];
        screenSize = nil;
    }
    
    [super dealloc];
}

#pragma mark - main methods

+ (LavenderDeviceInfo*)getInstance
{
    @synchronized([LavenderDeviceInfo class])
    {
        if(s_lavenderDeviceInfo == nil)
        {
            s_lavenderDeviceInfo = [[LavenderDeviceInfo alloc] init];
            
            [s_lavenderDeviceInfo initMembers];
        }
    }
    
    return s_lavenderDeviceInfo;
}

+ (void)destroyInstance
{
    @synchronized([LavenderDeviceInfo class])
    {
        if(s_lavenderDeviceInfo != nil)
        {
            [s_lavenderDeviceInfo release];
            s_lavenderDeviceInfo = nil;
        }
    }
}

@end


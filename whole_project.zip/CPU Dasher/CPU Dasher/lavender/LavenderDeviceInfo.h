//
//  LavenderDeviceInfo.h
//  Lavender
//
//  Created by Zenny Chen on 11-12-21.
//  Copyright (c) 2011年 chenyi. All rights reserved.
//

#import <UIKit/UIKit.h>

enum LAVENDER_DEVICE_NETWORK_STATUS
{
    LAVENDER_DEVICE_NETWORK_STATUS_NOT_CONNECTED,
    LAVENDER_DEVICE_NETWORK_STATUS_WIFI,
    LAVENDER_DEVICE_NETWORK_STATUS_OTHERS
};

enum LAVENDER_DEVICE_ARM_ISA_SUPPORT
{
    LAVENDER_DEVICE_ARM_ISA_SUPPORT_DEFAULT,
    LAVENDER_DEVICE_ARM_ISA_SUPPORT_ARMv6 = LAVENDER_DEVICE_ARM_ISA_SUPPORT_DEFAULT,
    LAVENDER_DEVICE_ARM_ISA_SUPPORT_NEON,
    LAVENDER_DEVICE_ARM_ISA_SUPPORT_NEON_VFPv4
};

@interface LavenderDeviceInfo : NSObject
{
@public
    
    // info that has to be got from sysctl
    NSString *macAddr;
    NSString *ipAddr;
    NSString *machineDetail;
    NSString *cpuType;
    NSString *armArch;
    NSInteger isaSupport;
    
    // device info
    NSString *deviceCategory;
    NSString *osVersion;
    NSUInteger nCores;
    long long memSize;
    
    // screen info
    NSString *screenSize;
    double pixelScale;
    
    // CPU Frequency
    NSInteger cpuFreq;
    NSTimeInterval absoluteFrequency;
    NSTimeInterval extraTimeCost;
    
    BOOL isLittleEndian;
    NSInteger pageSize;
    
    // Cache info
    long long cachelineSize;
    long long l1dCache;
    long long l1iCache;
    long long l2Cache;
    long long l3Cache;
}

+ (LavenderDeviceInfo*)getInstance;
+ (void)destroyInstance;

@end

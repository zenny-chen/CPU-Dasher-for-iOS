//
//  ZennyPlainImageViewController.h
//  CPU Dasher
//
//  Created by zenny_chen on 13-4-17.
//
//

#import <UIKit/UIKit.h>

@interface ZennyPlainImageViewController : UIViewController

@end

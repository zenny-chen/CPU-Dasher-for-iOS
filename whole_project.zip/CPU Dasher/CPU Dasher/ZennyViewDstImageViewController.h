//
//  ZennyViewDstImageViewController.h
//  CPU Dasher
//
//  Created by zenny_chen on 13-4-17.
//
//

#import <UIKit/UIKit.h>

@interface ZennyViewDstImageViewController : UIViewController
{
@public
    
    unsigned char *iImageBuffer;
    unsigned iImageWidth, iImageHeight;
}

@end

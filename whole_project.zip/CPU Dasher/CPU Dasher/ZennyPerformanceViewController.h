//
//  ZennyPerformanceViewController.h
//  CPU Dasher
//
//  Created by zenny_chen on 13-4-12.
//
//

#import <UIKit/UIKit.h>

@interface ZennyPerformanceViewController : UIViewController
{
    NSMutableArray **mTableCellList;
}

@end

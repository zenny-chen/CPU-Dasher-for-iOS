//
//  main.m
//  CPU Dasher
//
//  Created by Zenny Chen on 14-4-29.
//  Copyright (c) 2014年 GreenGames Studio. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

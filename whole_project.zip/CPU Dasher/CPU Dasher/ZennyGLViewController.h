//
//  ZennyGLViewController.h
//  CPU Dasher
//
//  Created by zenny_chen on 13-4-18.
//
//

#import <UIKit/UIKit.h>
#import "ZennyGLView.h"

@interface ZennyGLViewController : UIViewController
{
@public
    
    const void *iImageData;
    enum ZENNY_SHADER_CALC iCalcForm;
}

@end
